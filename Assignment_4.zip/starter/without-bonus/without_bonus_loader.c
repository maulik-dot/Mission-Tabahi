#include "loader.h"

Elf32_Ehdr *ehdr;
Elf32_Phdr *phdr;
int fd;
void *segment_memory;
/*
 * release memory and other cleanups
 */
void loader_cleanup() {
    
    close(fd);
  
}

/*
 * Load and run the ELF executable file
 */
void load_and_run_elf(char** exe) {
  fd = open(exe[1], O_RDONLY);
  if (fd == -1) {
        printf("Error opening file");
        return;
    }
  // 1. Load entire binary content into the memory from the ELF file.
  // Allocate memory on the heap for the file content
  Elf32_Ehdr *buffer = (Elf32_Ehdr *)malloc(sizeof(Elf32_Ehdr));
   if (buffer == NULL) {
        printf("Memory allocation error");
  }

    //Read the file content into the allocated memory
    ssize_t bytesRead = read(fd, buffer, sizeof(Elf32_Ehdr));
    if (bytesRead != sizeof(Elf32_Ehdr)) {
        printf("Error reading ELF header");
        free(buffer);
        close(fd);
        return;
    }
    off_t X=lseek(fd,buffer->e_phoff,SEEK_SET);
    Elf32_Phdr *buffer1 = (Elf32_Phdr *)malloc(sizeof(Elf32_Phdr));

    if (buffer1 == NULL) {
        printf("Memory allocation error");
  }
    ssize_t bytesRead1 = read(fd, buffer1, sizeof(Elf32_Phdr));
    if (bytesRead1 != sizeof(Elf32_Phdr)) {
        printf("Error reading Program header");
        free(buffer);
        free(buffer1);
        close(fd);
        return;
    }
  // 2. Iterate through the PHDR table and find the section of PT_LOAD
  //    type that contains the address of the entrypoint method in fib.c
   for (int i=0;i<buffer->e_phnum;i++){
    // lseek(fd, buffer->e_phoff + i* buffer ->e_phentsize, SEEK_SET );
    if (lseek(fd, buffer->e_phoff+ i * buffer->e_phentsize, SEEK_SET) == -1) {
            printf("Error seeking to program header");
            free(buffer);
            free(buffer1);

            close(fd);
            return;
        }

    // read(fd, buffer1, buffer -> e_phentsize);
    if (read(fd, buffer1, buffer -> e_phentsize) != sizeof(Elf32_Phdr)) {
            printf("Error reading program header");
            free(buffer);
            free(buffer1);
            close(fd);
            return;
        }
        
    if(buffer1->p_type==PT_LOAD){
	    if (buffer->e_entry >= buffer1->p_vaddr && buffer->e_entry < buffer1-> p_vaddr + buffer1->p_memsz){
      // printf("Segment Virtual Address: 0x%x\n", buffer1->p_vaddr);
      break;}
    }

  }
    Elf32_Addr segment_virtual_Address=buffer1->p_vaddr;

    // 3. Allocate memory of the size "p_memsz" using mmap function 
    //    and then copy the segment content
    segment_memory = mmap(NULL, buffer1->p_memsz, PROT_READ | PROT_WRITE | PROT_EXEC,
                                MAP_PRIVATE | MAP_ANONYMOUS, 0, 0);

    if (segment_memory == MAP_FAILED) {
        printf("Memory mapping error");
        free(buffer);
        free(buffer1);
        close(fd);
        return;
    }
    if(lseek(fd, buffer1->p_offset, SEEK_SET)==-1){
      printf("Error seeking to Segment");

      free(buffer);
      free(buffer1);
      close(fd);
      return;
    }
    if(read(fd, segment_memory, buffer1->p_filesz)!=buffer1->p_filesz){
      printf("Error reading the segment");

      free(buffer);
      free(buffer1);
      close(fd);
      return;
    }

    // 4. Navigate to the entrypoint address into the segment loaded in the memory in above step
      
    Elf32_Addr address = buffer->e_entry - segment_virtual_Address;

      // 5. Typecast the address to that of function pointer matching "_start" method in fib.c.
    int (*_start)()  = (int (*)()) (segment_memory + (address));
 
 
  // 6. Call the "_start" method and print the value returned from the "_start"
  int result = _start();
  printf("User _start return value = %d\n",result);
}


int main(int argc, char** argv) {

  if(argc != 2) {
    printf("Usage: %s <ELF Executable> \n",argv[0]);
    exit(1);
  }
  // 1. carry out necessary checks on the input ELF file
  // 2. passing it to the loader for carrying out the loading/execution
  load_and_run_elf(argv);
  // 3. invoke the cleanup routine inside the loader  
  loader_cleanup();
  return 0;
}
