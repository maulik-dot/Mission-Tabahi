#include "loader.h"
#include <signal.h>



int fd;
int page_faults = 0;
// int page_allocations = 0;
// size_t internal_fragmentation = 0;
void *segment_memory;
void loader_cleanup() {
    close(fd);
}

struct Segment{
    void* vaddr;
    size_t size;
    int loaded;
};

// struct sigaction {
//     void (*sa_handler)(int);         // Signal handler function (deprecated, use sa_sigaction)
//     void (*sa_sigaction)(int, siginfo_t*, void *); // Signal handler function (recommended)
//     sigset_t sa_mask;                // Set of signals to be blocked during the handler
//     int sa_flags;                    // Flags that modify the behavior of the handler
//     void (*sa_restorer)(void);       // Not used on most systems
// };


void segmentation_fault(int sig, siginfo_t *info, void *context){
    page_faults++;
    // printf("%d\n",page_faults);
    printf("hi");
    printf("Received segmentation fault (SIGSEGV) at address %p\n", info->si_addr);
    // exit(1);
}

void load_and_run_elf(const char* exe) {

    struct sigaction sa;
    sa.sa_sigaction = segmentation_fault;
    sa.sa_flags = NT_SIGINFO;
    // sigaction(SIGSEGV, &sa, NULL);

    fd = open(exe, O_RDONLY);
    if (fd == -1) {
        printf("Error opening file\n");
        return;
    }

    Elf32_Ehdr ehdr;
    if (read(fd, &ehdr, sizeof(Elf32_Ehdr)) != sizeof(Elf32_Ehdr)) {
        printf("Error reading ELF header\n");
        return;
    }

    Elf32_Phdr phdr;
    for (int i = 0; i < ehdr.e_phnum; i++) {
        if (lseek(fd, ehdr.e_phoff + i * ehdr.e_phentsize, SEEK_SET) == -1) {
            printf("Error seeking to program header\n");
            return;
        }
        if (read(fd, &phdr, sizeof(Elf32_Phdr)) != sizeof(Elf32_Phdr)) {
            printf("Error reading program header\n");
            return;
        }
        
        sigaction(SIGSEGV, &sa, NULL);
        // if (phdr.p_type == PT_LOAD && ehdr.e_entry >= phdr.p_vaddr && ehdr.e_entry < phdr.p_vaddr + phdr.p_memsz) {
            // printf("---------------------------\n");
            // // printf("%p\n",(void*)ehdr.e_entry);
            // printf("%p\n",(void*)phdr.p_vaddr + phdr.p_memsz);
            // Elf32_Addr offset = ehdr.e_entry - phdr.p_vaddr;
            // printf("Offset-%p\n",(void*)ehdr.e_entry - phdr.p_vaddr);
            // printf("---------------------------\n");
            

            // void* segment_memory = mmap(NULL, phdr.p_memsz, PROT_READ | PROT_WRITE | PROT_EXEC,
            //                             MAP_PRIVATE | MAP_ANONYMOUS, 0, 0);

            // printf("Segment_memory-%p\n",(void*)segment_memory+offset);

            // if (segment_memory == MAP_FAILED) {
            //     printf("Memory mapping error\n");
            //     return;
            // }
            // size_t fragment_size = phdr.p_memsz - phdr.p_filesz;
            // internal_fragmentation += fragment_size;
            // page_allocations++;

            // if (lseek(fd, phdr.p_offset, SEEK_SET) == -1) {
            //     printf("Error seeking to segment\n");
            //     return;
            // }
            // if (read(fd, segment_memory, phdr.p_filesz) != phdr.p_filesz) {
            //     printf("Error reading the segment\n");
            //     return;
            // }
            
        
    }
    int (*_start)() = (int (*)())(ehdr.e_entry);
    printf("%p\n",(void*)_start);
    int result = _start();
    printf("User _start return value = %d\n", result);
    printf("Entry point not found in any segment\n");
}

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s <ELF Executable>\n", argv[0]);
        exit(1);
    }

    load_and_run_elf(argv[1]);
    printf("Total Page Faults: %n\n", (int*)segmentation_fault);
    loader_cleanup();
    return 0;
}
